<?php
/*
Copyright 09-Januari-2020
MASCMS V1.0 (MAS Content Management System)
Coded by : Mohamad Abdul Sobur
Based on PHP NATIVE
*/

include("header.php");

$getpermalink = mysqli_real_escape_string($masdb, $_GET['title']);
$querylink = "SELECT * FROM post WHERE permalink='$getpermalink'";
//PERMALINK GET
$exec = $mas_class->mas_query($masdb, $querylink);
$permalink = mysqli_fetch_assoc($exec);
$date = $permalink['date'];

//DATE TYPE / TIPE TANGGAL (ID/EN)
if($_SESSION['lang'] == $lang_en)
{
	$date_post = $date;
}
else
{
	$date_post = masDateFormat($date);
}
//mulai
?>
<!--Content-->

<div class="container text-light bg-primary p-2">
    <span style="font-size: 20px;"><b><? echo $permalink['title']; ?></b></span>
    <div class="bg-primary p1">
		<span class="badge badge-light border-bottom-1 text-primary">
			<svg id="i-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="17" height="17" fill="none" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3">
    			<circle cx="16" cy="16" r="14" />
   			 <path d="M16 8 L16 16 20 20" />
			</svg>
			<?php echo $date_post; ?>
		</span>
	</div>
</div>
<div style="padding-bottom: 5px; margin-bottom: 5px;" class="container">
<?php
//Show Post
$t = $_GET['title'];
$query_view = "SELECT * FROM post WHERE permalink='$t' LIMIT 1";
$query_view2 = "SELECT * FROM post WHERE permalink='$t'";
$title_post = mysqli_real_escape_string($masdb, $t);
$result = $mas_class->mas_query($masdb, $query_view);
$r = $mas_class->mas_query($masdb, $query_view2);
$cat = mysqli_fetch_assoc($r);
$cat_result = $cat['category'];
$cat_result_strip = gantiSpasi($cat_result);

if(mysqli_num_rows($result) < 1)
{
	header("location: home.asp");
}
while($row = mysqli_fetch_assoc($result))
{
	$linkjudul = $row['title'];
    $id = $row['id'];
	$title = $row['title'];
	$time = $row['date'];
	$cat = $row['category'];
	$hits = $row['hits']+1;
	$keyword = $row['keyword'];
	
	//HITS / KUNJUNGAN
	$hits_add = "UPDATE post SET hits='$hits' WHERE id='$id'";
	$mas_class->mas_query($masdb, $hits_add);
	
	if($_SESSION['lang'] == $lang_en)
	{
		$description = $row['description_en'];
	}
	else
	{
		$description = $row['description'];
	}
	?>
	<div>
		<?php echo $description; ?>
	</div>
	<div class="table-responsive-sm">
		<table class="table table-sm table-dark table-bordered">
			<thead>
				<tr>
					<th scope="col"><span class="text-light"><?php echo $category_lang; ?></span></th>
					<th scope="col"><span class="text-light"><?php echo $hits_lang; ?></th>
					<th scope="col"><span class="text-light"><?php echo $keyword_lang; ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td class="bg-light"><span class="badge badge-sm badge-primary"><b><a class="text-light" href="cat.asp?category=<?php echo gantiSpasi($cat); ?>"><?php echo $cat; ?></a></b></span></td>
					<td class="bg-light"><span class="badge badge-sm badge-primary"><b><?php echo $hits; ?>×</b></span></td>
					<td class="bg-light">
					<?php
					$tag = masKeywordExploder($keyword);
					foreach($tag as $tags)
					{
					?>
						<span class="badge badge-sm badge-primary">
							<b>
								<a href="home.asp?keyword=<?php echo $tags; ?>" class="text-light"><?php echo $tags; ?></a>
							</b>
						</span>
					<?php
					}
					?>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
    <?php
}
?>
</div>

<!--List update content-->
<span class="d-block container text-light bg-dark p-2">
	<svg id="i-lightning" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="17" height="17" fill="none" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3">
    	<path d="M18 13 L26 2 8 13 14 19 6 30 24 19 Z" />
	</svg>
    <b><?php echo $latest_update_lang; ?></b>
</span>
<div class="container">
	<div class="row">
<?php
//PAGINATION 
$sql_pagination = "SELECT * from post";
$halaman = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 0;
$mulai = ($page > 1) ? ($page * $halaman) - $halaman : 0;
$result = $mas_class->mas_query($masdb, $sql_pagination);
$total = mysqli_num_rows($result);
$pages = ceil($total/$halaman);
$sql_list_post = "SELECT * FROM post ORDER BY id DESC LIMIT $mulai, $halaman";
//LIST POSTINGAN
$hasil = $mas_class->mas_query($masdb, $sql_list_post);
if(mysqli_num_rows($hasil) > 0)
{
	while($list = mysqli_fetch_assoc($hasil))
    {
    	$linkjudul = gantiSpasi($list['title']);
        $title = $list['title'];
        $permalink = $list['permalink'];
        $description = $list['description'];
        $date = $list['date'];
        $cat = $list['category'];
        $urlthumb = $list['urlthumb'];
        $hits = $list['hits'];
        
        //DATE TYPE / TIPE TANGGAL (ID/EN)
		if($_SESSION['lang'] == $lang_en)
		{
			$date_type = $date;
		}
		else
		{
			$date_type = masDateFormat($date);
		}
        ?>
        <div style="width: 100%; heigh: 300px;" class="mb-3 shadow-sm">
        	<div class="card w-100">
        		<a href="post.asp?title=<?php echo $permalink; ?>">
				<div class="card-body">
					<table>
						<tbody>
							<tr>
								<td>
									<img class="img-fluid img-thumbnail" style="min-width: 120px; min-height: 120px; max-width: 130px; max-height: 130px; margin-right: 3px;" src="<?php echo $urlthumb; ?>" alt="<?php echo $title; ?>"/>
								</td>
								<td>
									<h6 style="margin-bottom: 2px;"  class="text-primary"><b><?php echo $title; ?></b></h6>
   								 <span class="badge badge-success">
										<svg id="i-clock" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="17" height="17" fill="none" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round" stroke-width="3">
    										<circle cx="16" cy="16" r="14" />
   										 <path d="M16 8 L16 16 20 20" />
										</svg>
										<?php echo $date_type; ?>
									</span><br/>
   								 <span class="badge badge-dark">
										<svg id="i-tag" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="17" height="17" fill="none" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
  										  <circle cx="24" cy="8" r="2" />
    										<path d="M2 18 L18 2 30 2 30 14 14 30 Z" />
										</svg>
										<?php echo $cat; ?>
									</span><br/>
									<span class="badge badge-primary">
										<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24">
											<path fill="white" d="M15 12c0 1.654-1.346 3-3 3s-3-1.346-3-3 1.346-3 3-3 3 1.346 3 3zm9-.449s-4.252 8.449-11.985 8.449c-7.18 0-12.015-8.449-12.015-8.449s4.446-7.551 12.015-7.551c7.694 0 11.985 7.551 11.985 7.551zm-7 .449c0-2.757-2.243-5-5-5s-5 2.243-5 5 2.243 5 5 5 5-2.243 5-5z"/>
										</svg>
										<?php echo $hits; ?>
									</span>
   							 </td>
							</tr>
						</tbody>
					</table>
  		  	</div>
				</a>
			</div>
   	 </div>
    <?php
    }
}
?>
	</div>
</div>
<!--End Content-->
<?php
include("footer.php");
?>
